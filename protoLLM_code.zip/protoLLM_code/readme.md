# ProtoLLM
We provide the code for ProtoLLM and ProtoLLM+weight. Below is an overview of the main files and directories in our codebase.

## Files to run
- **run.py**: query and executes ProtoLLM
- **run_weighted.py**: query and executes ProtoLLM+weight, utilizing the queried feature weights to improve overall model performance.

## Directories
- **data**: Contains the datasets used for training and evaluation.
- **gpt_weights**: Stores the queried feature weights generated from LLMs.
- **oracle_features**: Stores the queried oracle features for each dataset.
- **results**: Stores AUC results.



# files to run
---
### run protoLLM
```bash
python run.py --data blood --shot 0 --seed 0 
```
---
### run protoLLM+weighted
```bash
python run_weighted.py --data blood --shot 0 --seed 0
```
---


# packages
- numpy=2.01
- scikit-learn=1.4.2
- pandas=2.1.4
- openai=1.25.0
- langchain=0.2.14