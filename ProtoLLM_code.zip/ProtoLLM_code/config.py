#datasets = ['adult', 'bank', 'blood', 'car', 'communities', 'credit-g', 'diabetes', 'heart', 'letter', 'myocardial', 'segment', 'cmc', 'dna', 'mfeat-karhunen', 'mfeat-pixel', 'optdigits', 'semeion']
datasets = ['adult','bank','blood','car','credit-g','heart','diabetes','myocardial','NHANES','cultivars']
n_class = {
    'adult':2,
    'bank':2,
    'blood':2,
    'car':4,
    'credit-g':2,
    'heart':2,
    'diabetes':2,
    'myocardial':2,
    'communities':2,
    'california_housing':2,
    'NHANES':2,
    'cultivars':2
}
seeds = range(15)
